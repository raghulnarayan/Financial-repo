
def simple_chatbot(user_query):
    if user_query == "What is Apple's total revenue in 2024?":
        return "Apple's total revenue in 2024 was $391,035 million."
    elif user_query == "What is Microsoft's net income in 2023?":
        return "Microsoft's net income in 2023 was $72,361 million."
    elif user_query == "How has Tesla's operating cash flow changed since 2022?":
        return "Tesla's operating cash flow increased significantly in 2024."
    elif user_query == "What is Apple's net income trend over 3 years?":
        return "Apple’s net income declined slightly from 2022 to 2024."
    elif user_query == "What is the total revenue for Tesla in 2023?":
        return "Tesla’s revenue in 2023 was $94,000 million."
    else:
        return "Sorry, I can only answer specific financial questions."

# Simple command-line chatbot interface
if __name__ == "__main__":
    while True:
        query = input("\nAsk a question (or type 'exit' to quit): ")
        if query.lower() == 'exit':
            print("Goodbye!")
            break
        response = simple_chatbot(query)
        print(response)
